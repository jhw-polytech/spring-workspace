package aop.xml;

public class Designer implements Employee{

	@Override
	public void work() {
		// TODO Auto-generated method stub
		System.out.println("디자인 중...");
	}

}
