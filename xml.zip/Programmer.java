package aop.xml;

public class Programmer implements Employee{

	@Override
	public void work() {
		// TODO Auto-generated method stub
		System.out.println("개발 중...");
	}

}
