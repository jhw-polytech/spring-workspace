package aop.xml;

public class Action {
	public void gotoOffice() {
		System.out.println("출근 중...");
	}
	
	public void getoffOffice() {
		System.out.println("퇴근 중...");
	}
}
