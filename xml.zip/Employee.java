package aop.xml;

public interface Employee {
	public void work();
}
